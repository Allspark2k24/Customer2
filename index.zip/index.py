import json
import boto3
import os

# Initialize the SES client
ses = boto3.client('ses')

def lambda_handler(event, context):
    try:
        # Check if 'Records' exists in the event and is not empty
        if 'Records' not in event or not event['Records']:
            raise ValueError("Event does not contain Records.")
        
        # Extract the SNS message from the event
        record = event['Records'][0]
        message = json.loads(record['Sns']['Message'])
        
        # Extract relevant details from the message
        alarm_name = message.get('AlarmName')
        instance_id = message.get('Trigger', {}).get('Dimensions', [{}])[0].get('value', 'Unknown')
        metric_name = message.get('Trigger', {}).get('MetricName', 'Unknown')
        threshold = message.get('Trigger', {}).get('Threshold', 'Unknown')
        
        # Define the email subject
        subject = f"Warning | Amazon Connect Alarm - {alarm_name}"

        # Define the email body
        body = (
            f"Dear Team,\n\n"
            f"Please note the following alarm has been triggered:\n\n"
            f"Metric: {metric_name}\n"
            f"Threshold Breached: {threshold}\n"
            f"Warning Alert - The {metric_name} has exceeded the threshold value of {threshold}. "
            f"This is causing an alarm. Please follow standard processing.\n\n"

            f"Full alarm details:\n{json.dumps(message, indent=2)}\n\n"
            f"Best regards,\n"
            f"Monitoring Team"
        )

        # Get the list of subscriber emails and source email from environment variables
        emails = os.environ['SUBSCRIBER_EMAILS'].split(',')
        source_email = os.environ['SOURCE_EMAIL']

        # Send the email to each address
        email_responses = []
        for email in emails:
            response = ses.send_email(
                Destination={'ToAddresses': [email]},
                Message={
                    'Body': {'Text': {'Data': body}},
                    'Subject': {'Data': subject}
                },
                Source=source_email
            )
            email_responses.append(response)
        
        # Return a success response with the email responses
        return {"status": "success", "responses": email_responses}

    except Exception as error:
        # Log and raise the error for debugging
        print(f"Error: {error}")
        raise error
